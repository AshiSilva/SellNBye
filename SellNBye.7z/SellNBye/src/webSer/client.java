package webSer;

import java.sql.Connection; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.sql.Statement;

import dbCon.DBConnection;

public class client
{

	public String getReviews() 
	{             
		String reviewGrid = null;             
		Connection con = null;             
		Statement st = null;             
		ResultSet rs = null;       
		
		try {       
			con = DBConnection.createConnection();     
			st = con.createStatement();    
			rs = st.executeQuery("select * from reviews");     
			
			if (rs.first())       
			{ 
				reviewGrid = "<table border='1' cellspacing='1' cellpadding='1'>"
						+ "<tr>"
						+ "<th>No</th>"
						+ "<th>Name</th>"
						+ "<th>Description</th>"
						+ "<th>Edit</th>"
						+ "<th>Delete</th>"
						+ "</tr>"; 
				rs.beforeFirst(); 
				
				while(rs.next())  
				{   
					reviewGrid = reviewGrid + "<tr><td>" + rs.getString(1) + 
							"</td>"      + "<td>" + rs.getString(2) + "</td>"     
							+ "<td>" + rs.getString(3) + "</td>"      
							+ "<td><input id=\"btnEdit\" type=\"button\" name=\"btnEdit\"  param=\"" 
							+ rs.getString(1) + "\" value=\"Edit\"</td>"      
							+ "<td>" + "<input id=\"btnRemove\" type=\"button\" name=\"btnRemove\" param=\"" 
							+ rs.getString(1) + "\" value=\"Remove\"</td></tr>";                        
				} 
				
			}                   
			else                         
				reviewGrid = "There are no items...";                   
			    reviewGrid = reviewGrid + "</table></br>";             
			}             
		catch (SQLException e) 
		{                   
			e.printStackTrace();             
		}             
		
		return reviewGrid;       
		
		}       
	
		public String saveAnItem(String cusID, String itemID,String description) 
		{
			String ret = null;             
			String sql = null;            
			Connection con = null;             
			Statement st = null;             
			try 
			{                   
				con = DBConnection.createConnection();                  
				st = con.createStatement();                  
				sql = "insert into reviews (cusID,itmID,description) values ('" + cusID + "', '" + itemID + "','" + description +"')";                   
				st.executeUpdate(sql);                   
				ret = "Successfully added";             
			}             
			catch (SQLException e) 
			{                   
				e.printStackTrace();             
			}             
			
			return ret;    
			

			$(document).on("click","#btnEdit",function()
			{
				$("#cusID").val(update);
				$("#itemID").val($(this).attr("param"));
				$("#txtdescription").val($(this).closest("tr").find('td:eq(1)').text());
				
			}
		
			$(document).on("click","#btnRemove", function()
			{
				$("#description").val("remove");
				$("#cusID").val($(this).attr("param"));
				var res = confirm("Do you want to delete?");
					if(res == true){
						$("#formItems").submit();
					}


			}

			
		}
			}
		
		
	


